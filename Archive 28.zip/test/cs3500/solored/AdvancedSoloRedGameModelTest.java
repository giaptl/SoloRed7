package cs3500.solored;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import cs3500.solored.model.hw02.Card;
import cs3500.solored.model.hw02.CardColors;
import cs3500.solored.model.hw02.CardPiece;
import cs3500.solored.model.hw02.RedGameModel;
import cs3500.solored.model.hw02.SoloRedGameModel;
import cs3500.solored.model.hw04.AdvancedSoloRedGameModel;
import cs3500.solored.view.hw02.SoloRedGameTextView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

/**
 *
 */
public class AdvancedSoloRedGameModelTest {

  private RedGameModel<Card> model;
  private List<Card> deck;

  @Before
  public void setUp() {
    model = new AdvancedSoloRedGameModel();
    deck = model.getAllCards();
  }

  // Test that deck is created with the correct number of cards
  @Test
  public void testDeckIsCorrectSize() {

    model.startGame(deck, true, 4, 5);
    // Check deck AFTER handing out initial cards
    assertEquals(26, model.numOfCardsInDeck());
  }


  // Test starting the game with a small deck
  @Test
  public void testStartGameSmallDeck() {
    assertThrows(IllegalArgumentException.class,
            () -> model.startGame(model.getAllCards().subList(0, 5), false, 4, 5));
  }

  // Test starting the game with non-unique cards
  @Test
  public void testStartGameNonUniqueCards() {
    List<Card> nonUniqueDeck = new ArrayList<>(model.getAllCards());
    nonUniqueDeck.add(nonUniqueDeck.get(0)); // Add a duplicate card
    assertThrows(IllegalArgumentException.class,
            () -> model.startGame(nonUniqueDeck, false, 4, 5));
  }

  // Test starting the game with null cards
  @Test
  public void testStartGameNullCards() {
    List<Card> nullDeck = new ArrayList<>(model.getAllCards());
    nullDeck.set(0, null);
    assertThrows(IllegalArgumentException.class,
            () -> model.startGame(nullDeck, false, 4, 5));
  }

  // Test starting the game with valid deck and args
  @Test
  public void testStartGameWithValidDeckAndArgs() {
    model.startGame(deck, true, 4, 5);
    assertEquals(4, model.numPalettes());
    assertEquals(5, model.getHand().size());
    assertEquals(26, model.numOfCardsInDeck());
  }

  // Test view with valid game
  @Test
  public void testViewWithValidGame() {
    model.startGame(deck, true, 4, 5);
    SoloRedGameTextView view = new SoloRedGameTextView(model);
    String gameState = view.toString();
    assertTrue(gameState.contains("Canvas:"));
    assertTrue(gameState.contains("P1:"));
    assertTrue(gameState.contains("Hand:"));
  }

  // Test random constructor results
  @Test
  public void testRandomConstructorResults() {
    Random random = new Random(42);
    SoloRedGameModel randomModel = new SoloRedGameModel(random);
    randomModel.startGame(randomModel.getAllCards(), true, 4, 5);
    List<Card> hand1 = randomModel.getHand();
    random = new Random(42);
    SoloRedGameModel anotherRandomModel = new SoloRedGameModel(random);
    anotherRandomModel.startGame(anotherRandomModel.getAllCards(), true, 4, 5);
    List<Card> hand2 = anotherRandomModel.getHand();
    assertEquals(hand1, hand2);
  }

  // Test hand is immutable
  @Test
  public void testHandIsImmutable() {
    model.startGame(deck, true, 4, 5);
    List<Card> hand = model.getHand();
    hand.remove(0);
    assertEquals(5, model.getHand().size());
  }

  // Test playing from hand slides cards down
  @Test
  public void testPlayingFromHandSlidesCardsDown() {
    model.startGame(deck, true, 4, 5);
    model.playToPalette(2, 2);
    assertEquals(4, model.getHand().size());
    assertEquals(2, model.getPalette(2).size());
  }

  // Test playing from hand removes card from hand
  @Test
  public void testPlayingFromHandRemovesCardFromHand() {
    model.startGame(deck, false, 4, 5);
    Card card = model.getHand().get(0);
    model.playToPalette(1, 0);
    assertFalse(model.getHand().contains(card));
  }

//  // Test deck size decreases after drawing
//  @Test
//  public void testDeckSizeDecreasesAfterDrawing() {
//    model.startGame(deck, false, 4, 5);
//    model.playToPalette(1, 1);
//    model.drawForHand();
//    assertEquals(25, model.numOfCardsInDeck());
//  }

  // Test deck shuffles
  @Test
  public void testDeckShuffles() {
    List<Card> originalDeck = new ArrayList<>(deck);
    model.startGame(deck, true, 4, 5);
    List<Card> shuffledDeck = model.getHand();
    boolean isShuffled = false;
    for (int i = 0; i < originalDeck.size(); i++) {
      if (!originalDeck.get(i).equals(shuffledDeck.get(i))) {
        isShuffled = true;
        break;
      }
    }
    assertTrue("The deck should be shuffled", isShuffled);
  }

  // Test canvas constructor
  @Test
  public void testCanvasConstructor() {
    model.startGame(deck, true, 4, 5);
    assertEquals(new CardPiece(CardColors.R, 1), model.getCanvas());
  }

}
