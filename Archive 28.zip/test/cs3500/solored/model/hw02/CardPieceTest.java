package cs3500.solored.model.hw02;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Test class for the CardPiece class.
 */
public class CardPieceTest {

  // Tests the creation of a valid CardPiece
  @Test
  public void testValidCardPieceCreation() {
    CardPiece card = new CardPiece(CardColors.R, 5);
    assertEquals(CardColors.R, card.getColor());
    assertEquals(5, card.getNumber());
  }

  // Tests the creation of an invalid CardPiece with a negative number
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCardPieceCreationNegativeNumber() {
    new CardPiece(CardColors.R, -1);
  }

  // Tests the creation of an invalid CardPiece with a zero number
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCardPieceCreationZeroNumber() {
    new CardPiece(CardColors.R, 0);
  }

  // Tests the creation of an invalid CardPiece with a number too high
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCardPieceCreationNumberTooHigh() {
    new CardPiece(CardColors.R, 10); // Assuming the valid indexes are 1-9
  }

  // Tests the creation of an invalid CardPiece with a null color
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCardPieceCreationNullColor() {
    new CardPiece(null, 5);
  }

  // Tests the toString method on a CardPiece
  @Test
  public void testToString() {
    CardPiece card = new CardPiece(CardColors.R, 5);
    assertEquals("R5", card.toString());
  }

  // Tests the toString method on a CardPiece that is a start card
  @Test
  public void testToStringStartCard() {
    CardPiece card = new CardPiece(CardColors.R, 5);
    CardPiece.isStartCard = true;
    assertEquals("R", card.toString());
  }

}
