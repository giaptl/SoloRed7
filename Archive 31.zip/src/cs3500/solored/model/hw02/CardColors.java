package cs3500.solored.model.hw02;

/**
 * Represents the colors of the cards in the game.
 */
public enum CardColors {

  R, O, B, I, V

}
