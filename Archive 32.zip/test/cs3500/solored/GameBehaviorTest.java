package cs3500.solored;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import cs3500.solored.model.hw02.Card;
import cs3500.solored.model.hw02.CardColors;
import cs3500.solored.model.hw02.CardPiece;
import cs3500.solored.model.hw02.SoloRedGameModel;

import static org.junit.Assert.assertTrue;

/**
 * Test class for specific behaviors of SoloRed
 */
public class GameBehaviorTest {

  // Test if soloredgamemodel is created with a deck of 4 cards
  // Game should be lost with 4 red cards in deck  and lower card played on any palette under
  // red rules
  @Test
  public void testGameLostWithFourRedCardsInDeck() {
    // Create a deck with 4 red cards
    List<Card> deck = new ArrayList<>();
    deck.add(new CardPiece(CardColors.R, 2));
    deck.add(new CardPiece(CardColors.R, 3));
    deck.add(new CardPiece(CardColors.R, 4));
    deck.add(new CardPiece(CardColors.R, 5));
    deck.add(new CardPiece(CardColors.R, 6));

    // Create the game model
    SoloRedGameModel model = new SoloRedGameModel();

    // Start the game with the deck, shuffle set to false, 4 players, and 5 cards per player
    model.startGame(deck, false, 4, 1);

    // Simulate playing a lower card on any palette under red rules
    model.playToPalette(1, 0); // Assuming the first card in hand is lower

    // Check if the game is lost
    assertTrue("The game should be lost with 4 red cards in deck and lower card " +
            "played on any palette under red rules", model.isGameOver());
  }
}
