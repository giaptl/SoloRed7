package cs3500.solored;

public final class SoloRed {

  /**
   * Main method to run the Solo Red game.
   * Documentation: <a href="https://docs.oracle.com/javase/tutorial/essential/environment/cmdLineArgs.html">...</a>
   *
   * @param args
   */
  public static void main(String[] args) {


  }
}
