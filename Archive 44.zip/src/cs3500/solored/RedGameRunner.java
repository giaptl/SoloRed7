package cs3500.solored;

import cs3500.solored.controller.SoloRedTextController;
import cs3500.solored.model.hw02.Card;
import cs3500.solored.model.hw02.SoloRedGameModel;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.Random;

/**
 * Represents a runner for the Solo Red game.
 */
public class RedGameRunner {

  /**
   * Main method to run the Solo Red game.
   *
   * @param args command line arguments
   */
  public static void main(String[] args) {
    SoloRedGameModel game = new SoloRedGameModel(new Random());
    List<Card> deck = game.getAllCards(); // Get the deck before starting the game

    Appendable writer = new BufferedWriter(new OutputStreamWriter(System.out));
    SoloRedTextController controller = new SoloRedTextController(new InputStreamReader(System.in),
        writer);

    // Start the game
    controller.playGame(game, deck, true, 4, 5);

  }
}