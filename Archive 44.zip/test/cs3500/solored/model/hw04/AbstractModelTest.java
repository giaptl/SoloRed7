package cs3500.solored.model.hw04;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import cs3500.solored.model.hw02.Card;
import cs3500.solored.model.hw02.CardColors;
import cs3500.solored.model.hw02.CardPiece;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Test class for implementation-specific details for AbstractSoloRedGameModel.
 */
public class AbstractModelTest {
  private TestSoloRedGameModel game;
  private List<Card> testDeck;

  // Create a concrete implementation of AbstractSoloRedGameModel for testing
  private static class TestSoloRedGameModel extends AbstractSoloRedGameModel {
    public TestSoloRedGameModel(Random random) {
      super(random);
    }

    @Override
    public void playToCanvas(int cardIdxInHand) {
      super.playToCanvas(cardIdxInHand);
      canvas = hand.remove(cardIdxInHand);
      playedToCanvasThisTurn = true;
    }

    @Override
    public void drawForHand() {
      super.drawForHand();
      if (!deck.isEmpty()) {
        hand.add(deck.poll());
      }
      playedToCanvasThisTurn = false;
    }
  }

  @Before
  public void setUp() {
    game = new TestSoloRedGameModel(new Random(42));
    testDeck = game.getAllCards();
  }

  // Test game starts correctly
  @Test
  public void testStartGame() {
    game.startGame(testDeck, false, 4, 5);
    assertFalse(game.isGameOver());
    assertEquals(4, game.numPalettes());
    assertEquals(5, game.getHand().size());
    assertEquals(testDeck.size() - 9, game.numOfCardsInDeck());
  }

  // Test game throws IllegalStateException if started after it has already started
  @Test(expected = IllegalStateException.class)
  public void testStartGameTwice() {
    game.startGame(testDeck, false, 4, 5);
    game.startGame(testDeck, false, 4, 5);
  }

  // Test game throws IllegalArgumentException if started with invalid parameters
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameWithInvalidPaletteCount() {
    game.startGame(testDeck, false, 1, 5);
  }

  // Test game throws IllegalArgumentException if started with invalid parameters
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameWithInvalidHandSize() {
    game.startGame(testDeck, false, 4, 0);
  }

  // Test play to palette works
  @Test
  public void testPlayToPalette() {
    game.startGame(testDeck, false, 4, 5);
    int initialHandSize = game.getHand().size();
    game.playToPalette(1, 0);
    assertEquals(initialHandSize - 1, game.getHand().size());
    assertEquals(2, game.getPalette(1).size());
  }

  // Test play to palette throws IllegalStateException if game has not started
  @Test(expected = IllegalStateException.class)
  public void testPlayToPaletteBeforeGameStart() {
    game.playToPalette(0, 0);
  }

  // Test play to palette throws IllegalStateException with invalid parameters
  @Test(expected = IllegalArgumentException.class)
  public void testPlayToPaletteInvalidPaletteIndex() {
    game.startGame(testDeck, false, 4, 5);
    game.playToPalette(4, 0);
  }

  // Test play to palette throws IllegalArgumentException with invalid parameters
  @Test(expected = IllegalArgumentException.class)
  public void testPlayToPaletteInvalidCardIndex() {
    game.startGame(testDeck, false, 4, 5);
    game.playToPalette(0, 5);
  }

  // Test play to canvas works
  @Test
  public void testPlayToCanvas() {
    game.startGame(testDeck, false, 4, 5);
    int initialHandSize = game.getHand().size();
    game.playToCanvas(0);
    assertEquals(initialHandSize - 1, game.getHand().size());
    assertNotNull(game.getCanvas());
  }

  // Test IllegalStateException is thrown when playing to canvas twice in a row
  @Test(expected = IllegalStateException.class)
  public void testPlayToCanvasTwiceInOneTurn() {
    game.startGame(testDeck, false, 4, 5);
    game.playToCanvas(0);
    game.playToCanvas(0);
  }

  // Test draw method works
  @Test
  public void testDrawForHand() {
    game.startGame(testDeck, false, 4, 5);
    int initialHandSize = game.getHand().size();
    int initialDeckSize = game.numOfCardsInDeck();
    game.drawForHand();
    assertEquals(initialHandSize + 1, game.getHand().size());
    assertEquals(initialDeckSize - 1, game.numOfCardsInDeck());
  }

  // Test game is over when deck is empty
  @Test
  public void testIsGameOver() {
    game.startGame(testDeck, false, 4, 5);
    assertFalse(game.isGameOver());

    // Empty the deck and hand
    while (!game.deck.isEmpty()) {
      game.deck.poll();
    }
    game.hand.clear();

    assertTrue(game.isGameOver());
  }

  // Test game is over when won
  @Test
  public void testIsGameWon() {
    game.startGame(testDeck, false, 4, 5);

    // Empty the deck and hand
    while (!game.deck.isEmpty()) {
      game.deck.poll();
    }
    game.hand.clear();

    game.isGameOver();
    assertTrue(game.isGameWon());
  }

  // Test winning palette index is valid index
  @Test
  public void testWinningPaletteIndex() {
    game.startGame(testDeck, false, 4, 5);
    int winningIndex = game.winningPaletteIndex();
    assertTrue(winningIndex >= 0 && winningIndex < 4);
  }

  // Test behavior to get all cards work
  @Test
  public void testGetAllCards() {
    List<Card> allCards = game.getAllCards();
    assertEquals(35, allCards.size()); // 5 colors * 7 numbers
  }

  // Test behavior for red rule
  @Test
  public void testIsWinningRed() {
    game.startGame(testDeck, false, 4, 5);
    game.canvas = new CardPiece(CardColors.R, 1);
    int winningIndex = game.isWinning();
    assertTrue(winningIndex >= 0 && winningIndex < 4);
  }

  // Test behavior for orange rule
  @Test
  public void testIsWinningOrange() {
    game.startGame(testDeck, false, 4, 5);
    game.canvas = new CardPiece(CardColors.O, 1);
    int winningIndex = game.isWinning();
    assertTrue(winningIndex >= 0 && winningIndex < 4);
  }

  // Test behavior for blue rule
  @Test
  public void testIsWinningBlue() {
    game.startGame(testDeck, false, 4, 5);
    game.canvas = new CardPiece(CardColors.B, 1);
    int winningIndex = game.isWinning();
    assertTrue(winningIndex >= 0 && winningIndex < 4);
  }

  // Test behavior for indigo rule
  @Test
  public void testIsWinningIndigo() {
    game.startGame(testDeck, false, 4, 5);
    game.canvas = new CardPiece(CardColors.I, 1);
    int winningIndex = game.isWinning();
    assertTrue(winningIndex >= 0 && winningIndex < 4);
  }

  // Test behavior for violet rule
  @Test
  public void testIsWinningViolet() {
    game.startGame(testDeck, false, 4, 5);
    game.canvas = new CardPiece(CardColors.V, 1);
    int winningIndex = game.isWinning();
    assertTrue(winningIndex >= 0 && winningIndex < 4);
  }

  // Test tie checking method works
  @Test
  public void testCheckForTie() {
    game.startGame(testDeck, false, 4, 5);
    List<Integer> tiedPalettes = new ArrayList<>();
    tiedPalettes.add(0);
    tiedPalettes.add(1);
    int winningIndex = game.checkForTie(game.palettes, tiedPalettes, -1);
    assertTrue(winningIndex == 0 || winningIndex == 1);
  }

}
