package cs3500.solored.model.hw04;

public enum CardNumbers {

  ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE

}
