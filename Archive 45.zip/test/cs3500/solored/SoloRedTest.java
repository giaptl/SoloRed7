package cs3500.solored;

public class SoloRedTest {

}
